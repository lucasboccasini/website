# Run Better. Live Better.

A responsive, static running and everyday wellness website for beginner and intermediate runners. The site shares practical starting points for sleep, nutrition, pre-run preparation, running, and lifestyle habits.

## Pages

- `index.html` — homepage and guide directory
- `sleep.html` — sleep and recovery habits
- `nutrition.html` — everyday fueling and hydration basics
- `before-run.html` — warm-up, gear, and pre-run checklist
- `running.html` — beginner training foundations and pacing
- `lifestyle.html` — sustainable habits and routine ideas
- `routine.html` — a browser-based weekly planning worksheet

## Run locally

Open `index.html` in a browser. The site uses plain HTML and CSS and has no build step or JavaScript dependency. Google Fonts are loaded from Google Fonts; the system font fallbacks work when offline.

The routine worksheet lets visitors enter a goal, check habits, and sketch a weekly plan in the current browser page. It does not save or send entries. Visitors can use the browser's print option to keep a copy.

## Publish with GitHub Pages

1. Create a GitHub repository and push this project to it.
2. In the repository, open **Settings → Pages**.
3. Select **Deploy from a branch**, choose the `main` branch and `/ (root)`, then save.
4. Open the Pages URL shown in the repository settings after deployment finishes.

All page links are relative, so they work from the repository root and a GitHub Pages project path.

## Content notes

Health content is general education, not individualized medical advice. Each guide links to further reading. Professional video areas are placeholders for future videos; no videos are included yet.
